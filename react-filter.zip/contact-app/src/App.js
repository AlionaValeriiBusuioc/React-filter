import React, {useState, useEffect} from "react";
import { uuid } from 'uuidv4';
import api from './api/contacts';
import './App.css';
import Header from './components/Header';
import AddContact from './components/AddContact';
import ContactList from './components/ContactList';

function App() {

const [contacts, setContacts] = useState([]);
const [searchTerm, setSearchTerm] = useState("");
const [searchResults, setSearchResults] = useState([]);

//RetrieveContacts
const retrieveContacts = async () =>{
  const response = await api.get("/contacts");
  return response.data;
}

const addContactHandler = async (contact) =>{
  console.log(contact);
  const request = {
   id:uuid(),
   ...contact
  }
  const response = await api.post("/contacts", request);
  console.log(response);
  
  setContacts([...contacts, response.data]);
}
//primim o copie a listei de contacte
const removeContactHandler = async (id) => {
  await api.delete(`/contacts/${id}`);
  const newContactList = contacts.filter((contact) => {
    return contact.id !== id;
  });

setContacts(newContactList);
}

const searchHandler = (searchTerm) => {
//  console.log(searchTerm);
setSearchTerm(searchTerm);
if(searchTerm !== ""){
  const newContactList = contacts.filter((contact) =>{
   return Object.values(contact)
   .join(" ")
   .toLowerCase()
   .includes(searchTerm.toLowerCase());
  });
  //update the state
  setSearchResults(newContactList);
}
else{
  setSearchResults(contacts);
}
}

useEffect(() =>{
 const getAllContacts = async() => {
   const allContacts = await retrieveContacts();
   if(allContacts) setContacts(allContacts);
 }
 getAllContacts();
 }, []);

useEffect(() =>{
 
}, [contacts]);
  return (
    <div className="ui container">
    <Header/>
    <AddContact addContactHandler={addContactHandler}/>
    <ContactList 
    // contacts={contacts} 
    contacts={searchTerm.length <1 ? contacts : searchResults} 
    getContactId={removeContactHandler}
    term={searchTerm}
    searchKeyword={searchHandler}
    />
    </div>
  );
}

export default App;
