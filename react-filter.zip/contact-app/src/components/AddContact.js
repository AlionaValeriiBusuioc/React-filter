import React, { Component } from 'react';

export default class AddContact extends Component {
    state = {
        name: ""
    }
    add = (e) =>{
        e.preventDefault();
        if(this.state.name === ""){
            alert("The field is mandatory!");
            return
        }
        this.props.addContactHandler(this.state);
        this.setState({name: ""});
        // console.log(this.state);
    }
    render() {
        return (
            <div className="ui main">
                <br/><br/>
                <h2>Add Name</h2>
                <form className="ui form" onSubmit={this.add}>
                    <div className="field">
                        <label>Name</label>
                        <input 
                        type="text" 
                        name="name" 
                        placeholder="Name" 
                        value={this.state.name}
                        onChange={(e) => this.setState({name: e.target.value})}/>
                    </div>
                    <button className="ui button blue">Add</button>
                </form>
            </div>
        )
    }
}
