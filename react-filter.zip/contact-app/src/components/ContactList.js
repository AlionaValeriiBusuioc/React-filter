import React, {useRef} from 'react';
import ContactCard from './ContactCard';
import './ContactList.css';
const ContactList = (props) => {
    // console.log(props);
    const inputEl = useRef("");
    const deleteContactHandler = (id) => {
        props.getContactId(id);
    };
    const renderContactList = props.contacts.map((contact) =>{
        return(
            <ContactCard contact={contact} clickHander = {deleteContactHandler} key={contact.id}></ContactCard>
        );
    });
    const getSearchTerm = () => {
    //  console.log(inputEl.current.value);
    props.searchKeyword(inputEl.current.value);
    }
    return (
        <div className="ui celled list"> 
       
        <div className ="ui search">
            <div className="ui icon input">
                <input type="text" 
                ref={inputEl}
                placeholder="Search Names" 
                className="prompt" 
                value={props.term} onChange={getSearchTerm}/>
                <i className="search icon"></i>
            </div>
        </div>
        <br/>
         {renderContactList.length > 0 ? renderContactList: "No contacts available"} 
        </div>
    )
}

export default ContactList;
