import React from 'react';

const Header = () => {
    return (
        <div className="ui fixed menu">
            <div className="ui container center">
             <h2>The list of Names</h2>
            </div>
        </div>
    )
}

export default Header;
